bl_info = {
    "name": "SuperBaker",
    "author": "Tu Nombre & Gemini",
    "version": (1, 9, 1), # Incrementada versión por correcciones en guardado
    "blender": (4, 2, 0),
    "location": "Properties > Render Properties > SuperBaker",
    "description": "Hornea: 1.Wall/Floor/Frames. 2.Paneles Cerrados (con W/F). 3.Paneles Abiertos (con W/F). 4.Techos (con todo visible).",
    "warning": "",
    "doc_url": "",
    "category": "Render",
}

import bpy
import uuid
import os
import re # Para expresiones regulares en los nombres
from pathlib import Path # <--- AÑADIDO PARA MEJOR MANEJO DE RUTAS
from bpy.props import EnumProperty, IntProperty, BoolProperty, StringProperty, PointerProperty
from bpy.types import PropertyGroup, Panel, Operator

# --- Property Group (con el cambio en save_path de la respuesta anterior) ---
class SSGB_Properties(PropertyGroup):
    bake_resolution_items = [
        ("1024", "1K (1024x1024)", "Hornear a resolución 1K"),
        ("2048", "2K (2048x2048)", "Hornear a resolución 2K"),
        ("4096", "4K (4096x4096)", "Hornear a resolución 4K"),
    ]
    bake_resolution: EnumProperty(
        name="Resolución", description="Resolución base para el horneado",
        items=bake_resolution_items, default="4096"
    )
    resize_percentage_items = [
        ("NONE", "Ninguno", "No redimensionar"), ("50", "50%", "Redimensionar al 50%"),
        ("25", "25%", "Redimensionar al 25%"),
    ]
    resize_percentage: EnumProperty(
        name="Redimensionar a", description="Redimensionar la imagen horneada",
        items=resize_percentage_items, default="50"
    )
    save_baked_image: BoolProperty(
        name="Guardar Imagen Horneada", description="Guardar la imagen horneada externamente",
        default=True
    )
    save_path: StringProperty(
        name="Ruta", description="Directorio para guardar la imagen horneada",
        default="//textures/", subtype='DIR_PATH' # Usando "/" como se sugirió
    )
    image_format_items = [
        ("PNG", "PNG", ""), ("JPEG", "JPEG", ""), ("OPEN_EXR", "OpenEXR", ""), ("TIFF", "TIFF", ""),
    ]
    image_format: EnumProperty(
        name="Formato", description="Formato de archivo para la imagen guardada",
        items=image_format_items, default="JPEG"
    )
    jpeg_quality: IntProperty(
        name="Calidad", description="Calidad para JPEG (0-100)",
        default=90, min=0, max=100, subtype='PERCENTAGE'
    )
    exr_codec_items = [
        ("NONE", "None", ""), ("ZIP", "ZIP", ""), ("ZIPS", "ZIPs", ""),
        ("PIZ", "PIZ", ""), ("RLE", "RLE", ""), ("DWAA", "DWAA", ""), ("DWAB", "DWAB", ""),
    ]
    exr_codec: EnumProperty(
        name="EXR Codec", description="Códec para OpenEXR",
        items=exr_codec_items, default="ZIP"
    )

# --- Operador Popup (sin cambios) ---
class SSGB_OT_ShowMessagePopup(Operator):
    bl_idname = "ssgb.show_message_popup"; bl_label = "Información de Horneado"
    bl_options = {'REGISTER', 'INTERNAL'}
    message: StringProperty(default="Procesando...")
    def execute(self, context): return {'FINISHED'}
    def invoke(self, context, event): return context.window_manager.invoke_popup(self, width=300)
    def draw(self, context): self.layout.label(text=self.message)

# --- Operador de Horneado ---
class SSGB_OT_BakeGroups(Operator):
    bl_idname = "ssgb.bake_groups"
    bl_label = "Cámara a Bakear Prros!"
    bl_description = "Inicia el proceso de horneado para los grupos definidos en etapas"
    bl_options = {'REGISTER', 'UNDO'}

    todos_los_objetos_involucrados_en_horneado = []

    def _manage_visibility_for_bake_stage(self, context, list_of_groups_to_show):
        objects_to_make_visible_set = set()
        for group in list_of_groups_to_show:
            for obj_in_group in group: 
                objects_to_make_visible_set.add(obj_in_group)

        for obj in self.todos_los_objetos_involucrados_en_horneado:
            if obj in objects_to_make_visible_set:
                obj.hide_render = False
            else:
                obj.hide_render = True
        
        context.view_layer.update()

    def _ejecutar_horneado_interno(self, context, nombre_etapa_actual, grupo_actual_a_hornear):
        if not grupo_actual_a_hornear: 
            self.report({'INFO'}, f"ETAPA: '{nombre_etapa_actual}' no tiene objetos principales para hornear. Saltando.")
            return True 

        self.report({'INFO'}, f"ETAPA: Iniciando horneado de '{nombre_etapa_actual}' (Objetos principales: {len(grupo_actual_a_hornear)})...")
        
        bpy.ops.object.select_all(action='DESELECT')
        active_obj_set = False
        for obj_sel in grupo_actual_a_hornear: 
            if obj_sel.name in bpy.data.objects:
                 obj_sel.select_set(True)
                 if not active_obj_set: 
                     context.view_layer.objects.active = obj_sel
                     active_obj_set = True
        
        if not active_obj_set:
            self.report({'ERROR'}, f"ETAPA: No se pudo encontrar un objeto activo válido en '{nombre_etapa_actual}' para hornear. Saltando horneado.")
            return False

        context.view_layer.update()
        try: bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
        except Exception as e_redraw: print(f"Advertencia: Falló redraw_timer en etapa '{nombre_etapa_actual}': {e_redraw}")
        
        try:
            bpy.ops.object.bake(type='DIFFUSE', pass_filter={'COLOR'}, use_clear=False)
            self.report({'INFO'}, f"ETAPA: Horneado de '{nombre_etapa_actual}' completado.")
            return True
        except RuntimeError as e:
            self.report({'ERROR'}, f"ETAPA: Error horneando '{nombre_etapa_actual}': {e}")
            return False
        except Exception as e_gen:
            self.report({'ERROR'}, f"ETAPA: Error inesperado horneando '{nombre_etapa_actual}': {e_gen}")
            return False

    def execute(self, context):
        scene = context.scene
        ssgb_props = scene.ssgb_props
        view_layer = context.view_layer
        
        bpy.ops.ssgb.show_message_popup('INVOKE_DEFAULT', message="¡Espera pacientemente el Bakeado Multi-Etapa!")
        try: bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
        except Exception as e_redraw: print(f"Advertencia: Falló redraw_timer inicial: {e_redraw}")

        self.report({'INFO'}, "--- Iniciando SuperBaker v1.9.1 ---")

        objetos_seleccionados_originalmente = [obj for obj in context.selected_objects if obj.type == 'MESH']
        if not objetos_seleccionados_originalmente:
            self.report({'ERROR'}, "No hay objetos de malla seleccionados."); return {'CANCELLED'}
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        estado_hide_render_original = {obj.name: obj.hide_render for obj in bpy.data.objects}
        original_active_object = context.active_object

        # --- Clasificación de Objetos ---
        grupo_muros_suelos_frames = []
        grupo_techos = []
        grupo_paneles_cerrados = [] 
        grupo_paneles_abiertos = [] 
        
        patron_closet_door_base = r"wall\d+_closet\d+_door\d+_"
        patron_frame = patron_closet_door_base + r"frame\d+"
        patron_open_left_panel = patron_closet_door_base + r"openleftpanel\d+"
        patron_closed_left_panel = patron_closet_door_base + r"closedleftpanel\d+"
        patron_open_right_panel = patron_closet_door_base + r"openrightpanel\d+"
        patron_closed_right_panel = patron_closet_door_base + r"closedrightpanel\d+"

        for obj in objetos_seleccionados_originalmente:
            obj_name = obj.name
            if re.fullmatch(patron_closed_left_panel, obj_name) or re.fullmatch(patron_closed_right_panel, obj_name):
                grupo_paneles_cerrados.append(obj)
            elif re.fullmatch(patron_open_left_panel, obj_name) or re.fullmatch(patron_open_right_panel, obj_name):
                grupo_paneles_abiertos.append(obj)
            elif re.fullmatch(patron_frame, obj_name):
                grupo_muros_suelos_frames.append(obj)
            elif obj_name.startswith("wall") or obj_name.startswith("interiorwall") or obj_name.startswith("floor"):
                grupo_muros_suelos_frames.append(obj)
            elif obj_name.startswith("ceiling"):
                grupo_techos.append(obj)

        self.todos_los_objetos_involucrados_en_horneado = list(set(
            grupo_muros_suelos_frames + grupo_techos + grupo_paneles_cerrados + grupo_paneles_abiertos
        ))
        
        if not self.todos_los_objetos_involucrados_en_horneado:
            self.report({'ERROR'}, "No se encontraron objetos con nomenclatura válida para hornear.")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Grupo 'Muros/Suelos/Marcos': {[o.name for o in grupo_muros_suelos_frames]}")
        self.report({'INFO'}, f"Grupo 'Paneles Cerrados': {[o.name for o in grupo_paneles_cerrados]}")
        self.report({'INFO'}, f"Grupo 'Paneles Abiertos': {[o.name for o in grupo_paneles_abiertos]}")
        self.report({'INFO'}, f"Grupo 'Techos': {[o.name for o in grupo_techos]}")

        img_resolution = int(ssgb_props.bake_resolution)
        img_width, img_height = img_resolution, img_resolution
        bake_node_label = f"SSGB_BakeNode_{uuid.uuid4().hex[:4]}"

        if scene.render.engine != 'CYCLES': scene.render.engine = 'CYCLES'
        if scene.cycles.bake_type != 'DIFFUSE':
            self.report({'WARNING'}, f"UI Bake Type: '{scene.cycles.bake_type}'. Script usará DIFFUSE explícito.")
        
        imagen_global_nombre = f"AtlasHorneado_SSGB_v19_{uuid.uuid4().hex[:6]}"
        if imagen_global_nombre in bpy.data.images:
            bpy.data.images.remove(bpy.data.images[imagen_global_nombre])
        
        self.report({'INFO'}, f"Creando imagen GLOBAL '{imagen_global_nombre}' ({img_width}x{img_height}), Non-Color.")
        imagen_global_datos = bpy.data.images.new(name=imagen_global_nombre, width=img_width, height=img_height, alpha=False)
        imagen_global_datos.generated_color = (0.0, 0.0, 0.0, 1.0)
        try: imagen_global_datos.colorspace_settings.name = 'Non-Color'
        except TypeError: self.report({'WARNING'}, f"No se pudo establecer Non-Color para '{imagen_global_nombre}'.")
        imagen_global_datos.use_fake_user = True # Keep image data-block even if not used

        self.report({'INFO'}, "Preparando materiales con imagen global...")
        original_active_for_mat_prep = view_layer.objects.active
        for obj_actual in self.todos_los_objetos_involucrados_en_horneado:
            view_layer.objects.active = obj_actual 
            if not obj_actual.material_slots: continue
            for slot in obj_actual.material_slots:
                material = slot.material
                if not material: continue
                if not material.use_nodes: material.use_nodes = True
                node_tree = material.node_tree; nodes = node_tree.nodes
                for node in list(nodes): # Iterate over a copy for safe removal
                    if node.type == 'TEX_IMAGE' and node.label == bake_node_label:
                        nodes.remove(node)
                bake_target_node = nodes.new(type='ShaderNodeTexImage')
                bake_target_node.label = bake_node_label
                output_node = next((n for n in nodes if n.type.startswith('OUTPUT_')), None)
                if output_node: bake_target_node.location = output_node.location; bake_target_node.location.x -= 350
                bake_target_node.image = imagen_global_datos
                for node in nodes: node.select = False 
                bake_target_node.select = True 
                nodes.active = bake_target_node 
        if original_active_for_mat_prep and original_active_for_mat_prep.name in bpy.data.objects:
            view_layer.objects.active = original_active_for_mat_prep
        elif context.object and context.object.name in bpy.data.objects :
             view_layer.objects.active = context.object

        bake_exitoso_general = True 
        
        # --- ETAPA 1: Horneando Muros, Suelos y Marcos de Puerta ---
        self.report({'INFO'}, "\n--- ETAPA 1: Muros/Suelos/Marcos ---")
        self._manage_visibility_for_bake_stage(context, [grupo_muros_suelos_frames])
        if not self._ejecutar_horneado_interno(context, "Grupo_Muros_Suelos_Marcos", grupo_muros_suelos_frames):
            bake_exitoso_general = False

        # --- ETAPA 2: Horneando Paneles de Puerta Cerrados ---
        if bake_exitoso_general:
            self.report({'INFO'}, "\n--- ETAPA 2: Paneles Puerta Cerrados ---")
            self._manage_visibility_for_bake_stage(context, [grupo_paneles_cerrados, grupo_muros_suelos_frames])
            if not self._ejecutar_horneado_interno(context, "Grupo_Paneles_Cerrados", grupo_paneles_cerrados):
                bake_exitoso_general = False
        
        # --- ETAPA 3: Horneando Paneles de Puerta Abiertos ---
        if bake_exitoso_general:
            self.report({'INFO'}, "\n--- ETAPA 3: Paneles Puerta Abiertos ---")
            self._manage_visibility_for_bake_stage(context, [grupo_paneles_abiertos, grupo_muros_suelos_frames])
            if not self._ejecutar_horneado_interno(context, "Grupo_Paneles_Abiertos", grupo_paneles_abiertos):
                bake_exitoso_general = False

        # --- ETAPA 4: Horneando Techos ---
        if bake_exitoso_general: 
            self.report({'INFO'}, "\n--- ETAPA 4: Techos ---")
            all_bake_groups = [grupo_muros_suelos_frames, grupo_paneles_cerrados, grupo_paneles_abiertos, grupo_techos]
            all_valid_bake_groups = [g for g in all_bake_groups if g] 
            self._manage_visibility_for_bake_stage(context, all_valid_bake_groups)
            if not self._ejecutar_horneado_interno(context, "Grupo_Techos", grupo_techos):
                bake_exitoso_general = False

        # --- Post-Procesamiento de Imagen (SECCIÓN MODIFICADA) ---
        if bake_exitoso_general and imagen_global_datos:
            img_a_procesar = imagen_global_datos
            if ssgb_props.resize_percentage != "NONE":
                scale_factor = float(ssgb_props.resize_percentage) / 100.0
                new_w,new_h = int(img_width*scale_factor), int(img_height*scale_factor)
                if new_w > 0 and new_h > 0:
                    self.report({'INFO'}, f"Redimensionando '{img_a_procesar.name}' a {new_w}x{new_h}.")
                    img_a_procesar.scale(new_w, new_h)
            
            if ssgb_props.save_baked_image:
                try:
                    save_dir_str = bpy.path.abspath(ssgb_props.save_path) # Default es "//textures/"
                    save_dir_path = Path(save_dir_str)

                    if not bpy.data.is_saved and ssgb_props.save_path.startswith("//"):
                        self.report({'WARNING'}, "La ruta de guardado es relativa (//) pero el archivo .blend no está guardado. La imagen podría guardarse en una ubicación inesperada.")
                        # Considerar no proceder o forzar una ruta absoluta si .blend no está guardado.
                        # Por ahora, procederemos, pero el usuario debe ser consciente.

                    if not save_dir_path.exists():
                        self.report({'INFO'}, f"Creando directorio de guardado: {save_dir_path}")
                        save_dir_path.mkdir(parents=True, exist_ok=True)
                    
                    if save_dir_path.is_dir():
                        file_ext = ssgb_props.image_format.lower()
                        if ssgb_props.image_format == "OPEN_EXR":
                            file_ext = "exr"
                        elif ssgb_props.image_format == "JPEG":
                            file_ext = "jpg" # Blender usa .jpg para JPEG
                        
                        # imagen_global_nombre es el nombre base de antes
                        final_save_path_obj = save_dir_path / f"{imagen_global_nombre}.{file_ext}"
                        full_path_str = str(final_save_path_obj)

                        ts = bpy.data.scenes.new("__SSGB_TempSaveScene__")
                        try:
                            settings = ts.render.image_settings
                            settings.file_format = ssgb_props.image_format
                            
                            settings.color_mode = 'RGB' # El horneado difuso es RGB
                            if ssgb_props.image_format=='JPEG':
                                settings.quality=ssgb_props.jpeg_quality
                                settings.color_depth='8' # Explícitamente 8 para JPEG
                            elif ssgb_props.image_format=='OPEN_EXR':
                                settings.exr_codec=ssgb_props.exr_codec
                                settings.color_depth='32'
                            elif ssgb_props.image_format=='PNG':
                                settings.color_depth='8'
                                settings.compression=15
                            elif ssgb_props.image_format=='TIFF':
                                settings.color_depth='8'

                            image_to_save = bpy.data.images.get(imagen_global_nombre)
                            if image_to_save:
                                # Usar el truco de codificación/decodificación para la ruta del archivo
                                encoded_save_path_str = str(full_path_str).encode('utf-8').decode('utf-8')
                                
                                self.report({'INFO'}, f"Intentando guardar imagen en: '{full_path_str}' con formato '{settings.file_format}'...")
                                image_to_save.save_render(filepath=encoded_save_path_str, scene=ts)
                                self.report({'INFO'}, f"Imagen '{image_to_save.name}' guardada exitosamente en: '{full_path_str}'.")

                                # Actualizar las propiedades del datablock de la imagen para reflejar el guardado externo
                                if bpy.data.is_saved: # Intentar hacer la ruta relativa si el archivo .blend está guardado
                                    try:
                                        image_to_save.filepath = bpy.path.relpath(full_path_str)
                                    except ValueError: # Maneja casos como diferentes unidades en Windows
                                        image_to_save.filepath = full_path_str
                                else:
                                    image_to_save.filepath = full_path_str
                                
                                image_to_save.file_format = settings.file_format
                                image_to_save.source = 'FILE'
                                
                                if image_to_save.packed_file:
                                    try:
                                        image_to_save.unpack(method='REMOVE')
                                        self.report({'INFO'}, f"Imagen '{image_to_save.name}' desempacada.")
                                    except RuntimeError as e_unpack:
                                        self.report({'WARNING'}, f"No se pudo desempacar la imagen '{image_to_save.name}': {e_unpack}")
                            else:
                                self.report({'ERROR'}, f"No se encontró la imagen '{imagen_global_nombre}' para guardar.")
                        
                        except Exception as e_save:
                            self.report({'ERROR'}, f"No se pudo guardar la imagen '{imagen_global_nombre}' en '{full_path_str}'. Error: {e_save}")
                            bake_exitoso_general = False # Marcar como fallo si el guardado falló
                        finally:
                            bpy.data.scenes.remove(ts)
                    else:
                        self.report({'ERROR'}, f"Ruta de guardado '{save_dir_str}' no es un directorio válido o no se pudo crear.")
                        bake_exitoso_general = False # Marcar como fallo
                
                except Exception as e_path_setup:
                    self.report({'ERROR'}, f"Error configurando la ruta de guardado o directorios: {e_path_setup}")
                    bake_exitoso_general = False # Marcar como fallo

        elif not bake_exitoso_general:
             self.report({'WARNING'}, "El proceso de horneado no se completó en todas las etapas. No se guardará/redimensionará la imagen.")
        # --- FIN DE LA SECCIÓN MODIFICADA ---

        self.report({'INFO'}, "Restaurando estado original de Blender...")
        for obj_name, hide_state in estado_hide_render_original.items():
            if obj_name in bpy.data.objects: bpy.data.objects[obj_name].hide_render = hide_state
        bpy.ops.object.select_all(action='DESELECT')
        for obj_sel in objetos_seleccionados_originalmente:
            if obj_sel.name in bpy.data.objects: obj_sel.select_set(True)
        if original_active_object and original_active_object.name in bpy.data.objects:
            view_layer.objects.active = original_active_object
        self.todos_los_objetos_involucrados_en_horneado = []

        final_message = "Proceso de SuperBaker completado." if bake_exitoso_general else "SuperBaker finalizado con errores en algunas etapas."
        bpy.ops.ssgb.show_message_popup('INVOKE_DEFAULT', message=final_message)
        self.report({'INFO'}, f"--- {final_message} Éxito general: {bake_exitoso_general} ---")
        return {'FINISHED'} if bake_exitoso_general else {'CANCELLED'}

# --- Panel UI (sin cambios estructurales) ---
class SSGB_PT_BakePanel(Panel):
    bl_label = "SuperBaker"; bl_idname = "SSGB_PT_MainPanel"
    bl_space_type = 'PROPERTIES'; bl_region_type = 'WINDOW'
    bl_context = "render"
    bl_category = "SuperBaker" 
    bl_order = 0
    def draw(self, context):
        layout = self.layout; scene = context.scene; props = scene.ssgb_props
        box = layout.box(); col = box.column(align=True)
        col.label(text="Configuración de Horneado Base:")
        col.prop(props, "bake_resolution")
        col.separator(); col.label(text="Post-Procesamiento de Imagen:")
        col.prop(props, "resize_percentage")
        col.separator(); col.prop(props, "save_baked_image")
        if props.save_baked_image:
            row = col.row(align=True); row.prop(props, "save_path")
            rf = col.row(align=True); rf.prop(props, "image_format")
            if props.image_format == 'JPEG': rf.prop(props, "jpeg_quality")
            elif props.image_format == 'OPEN_EXR': rf.prop(props, "exr_codec")
        col.separator(); col.separator()
        rb = layout.row(); rb.scale_y = 1.5
        rb.operator(SSGB_OT_BakeGroups.bl_idname, icon='PLAY')

classes = (SSGB_Properties, SSGB_OT_ShowMessagePopup, SSGB_OT_BakeGroups, SSGB_PT_BakePanel)

def register():
    for cls in classes: bpy.utils.register_class(cls)
    bpy.types.Scene.ssgb_props = PointerProperty(type=SSGB_Properties)

def unregister():
    for cls in reversed(classes): bpy.utils.unregister_class(cls)
    del bpy.types.Scene.ssgb_props

if __name__ == "__main__":
    try: unregister()
    except Exception: pass
    register()
    print("SuperBaker v1.9.1 registrado con correcciones en guardado.")